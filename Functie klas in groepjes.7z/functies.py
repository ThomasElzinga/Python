#Thomas Elzinga
# 234184

def klasingroepjes(groepen, klaslijstin, klaslijstuit):
    import random
    klasfile = open(str(klaslijstin), "r")
    inhoud = klasfile.read()
    klas = inhoud.split("\n")
    klasgroote = len(klas)
    groepjes = int(groepen)
    klasfile.close()
    leegbestand = open(str(klaslijstuit), "w")
    leegbestand.write("")
    leegbestand.close()

    while klasgroote > 0 and groepjes > 0:
        groepje = random.sample(klas,int(klasgroote/groepjes))
        groepstr = str(groepje)
        #print (groepstr)
        klasgroote-=int(klasgroote/groepjes)
        groepjes-=1
        leegbestand = open(str(klaslijstuit), "a")
        leegbestand.write(groepstr + "\n")
        for x in groepje:
            klas.remove(x)
        leegbestand.close()

klasingroepjes(5, r"C:\\Software DV School\\opdrachten python\\Functie klas in groepjes\\klas1.txt", r"C:\\Software DV School\\opdrachten python\\Functie klas in groepjes\\verdeling1.txt")
klasingroepjes(8, r"C:\\Software DV School\\opdrachten python\\Functie klas in groepjes\\klas2.txt", r"C:\\Software DV School\\opdrachten python\\Functie klas in groepjes\\verdeling2.txt")